/* 
 * File:   main.cpp
 * Author: Alan Cano
 * Created on June 27, 2020, 12:01 AM
 * Purpose: Tony Gaddis Chapter 2 Problem 1
 */

#include <iostream>

using namespace std;

//User Libraries

//Global Constants Only
//Well known Science, Mathematical, and Laboratory COnstants only

//Function Prototypes

//Execution of code begins here
int main(int argc, char** argv) {
   

    
    //Set the random number seed here
    
    //Declare all variables for this function
    int fif, hun, tot; //fifty, hundred, total
    //Initialize all known variables
    fif = 50;
        hun = 100;
    //Process Inputs to Outputs -> Mapping Process
    //Maps all unknown objectives 
        tot = fif * hun
    //Display the Inputs/Outputs
    cout << "Total = " << tot << endl;
    //Clean Up the code, close files, deallocate memory,etc...
    //Exit stage right
    return 0;
}

